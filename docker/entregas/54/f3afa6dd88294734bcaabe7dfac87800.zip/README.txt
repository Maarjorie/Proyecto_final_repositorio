Aplicación de escritorio para la gestión de bibliotecas escolares

Código fuente del proyecto.
