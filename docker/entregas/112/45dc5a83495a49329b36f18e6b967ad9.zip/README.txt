Red de sensores para monitorear la humedad del suelo en cultivos

Código fuente del proyecto.
