Sistema de control de asistencia con reconocimiento facial

Código fuente del proyecto.
