Prototipo de iluminación pública con paneles solares y sensores

Código fuente del proyecto.
