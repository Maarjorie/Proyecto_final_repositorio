Monitoreo del consumo eléctrico con sensores de corriente y plataforma web

Código fuente del proyecto.
