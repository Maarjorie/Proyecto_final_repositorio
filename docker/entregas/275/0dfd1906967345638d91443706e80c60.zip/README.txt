Diseño de una base de datos para un consultorio odontológico

Código fuente del proyecto.
