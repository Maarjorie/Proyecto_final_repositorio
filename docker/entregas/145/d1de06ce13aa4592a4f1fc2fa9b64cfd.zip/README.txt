Detección de enfermedades en hojas de café con redes neuronales

Código fuente del proyecto.
